var O = Object.defineProperty,
	k = Object.defineProperties;
var _ = Object.getOwnPropertyDescriptors;
var T = Object.getOwnPropertySymbols;
var N = Object.prototype.hasOwnProperty,
	R = Object.prototype.propertyIsEnumerable;
var P = (a, e, t) => e in a ? O(a, e, {
		enumerable: !0,
		configurable: !0,
		writable: !0,
		value: t
	}) : a[e] = t,
	D = (a, e) => {
		for (var t in e || (e = {})) N.call(e, t) && P(a, t, e[t]);
		if (T)
			for (var t of T(e)) R.call(e, t) && P(a, t, e[t]);
		return a
	},
	A = (a, e) => k(a, _(e));
var p = (a, e, t) => P(a, typeof e != "symbol" ? e + "" : e, t);
(function() {
	const e = document.createElement("link").relList;
	if (e && e.supports && e.supports("modulepreload")) return;
	for (const n of document.querySelectorAll('link[rel="modulepreload"]')) i(n);
	new MutationObserver(n => {
		for (const r of n)
			if (r.type === "childList")
				for (const d of r.addedNodes) d.tagName === "LINK" && d.rel === "modulepreload" && i(d)
	}).observe(document, {
		childList: !0,
		subtree: !0
	});

	function t(n) {
		const r = {};
		return n.integrity && (r.integrity = n.integrity), n.referrerPolicy && (r.referrerPolicy = n.referrerPolicy), n.crossOrigin === "use-credentials" ? r.credentials = "include" : n.crossOrigin === "anonymous" ? r.credentials = "omit" : r.credentials = "same-origin", r
	}

	function i(n) {
		if (n.ep) return;
		n.ep = !0;
		const r = t(n);
		fetch(n.href, r)
	}
})();
var w = (a => (a.up = "up", a.down = "down", a.left = "left", a.right = "right", a))(w || {}),
	x = (a => (a.onOff = "onOff", a.variable = "variable", a))(x || {}),
	L = (a => (a.real = "real", a.emulated = "emulated", a.overlay = "overlay", a))(L || {}),
	F = (a => (a[a.A = 0] = "A", a[a.B = 1] = "B", a[a.X = 2] = "X", a[a.Y = 3] = "Y", a[a.LShoulder = 4] = "LShoulder", a[a.RShoulder = 5] = "RShoulder", a[a.LTrigger = 6] = "LTrigger", a[a.RTrigger = 7] = "RTrigger", a[a.Back = 8] = "Back", a[a.Start = 9] = "Start", a[a.LStick = 10] = "LStick", a[a.RStick = 11] = "RStick", a[a.DPadUp = 12] = "DPadUp", a[a.DPadDown = 13] = "DPadDown", a[a.DPadLeft = 14] = "DPadLeft", a[a.DPadRight = 15] = "DPadRight", a[a.Vendor = 16] = "Vendor", a))(F || {}),
	j = (a => (a[a.LStickX = 0] = "LStickX", a[a.LStickY = 1] = "LStickY", a[a.RStickX = 2] = "RStickX", a[a.RStickY = 3] = "RStickY", a))(j || {}),
	S = (a => (a.TapTarget = "gpad-tap-target", a.ButtonIcon = "gpad-btn-icon", a.ButtonShadow = "gpad-shadow", a.ButtonHighlight = "gpad-highlight", a.ButtonBackground = "gpad-btn-bg", a.DirectionHighlight = "gpad-direction-highlight", a.Thumbstick = "gpad-thumbstick", a.GpadBaseShape = "gpad-base", a.StickBaseShape = "gpad-stick-base", a))(S || {});
const B = ["button_1", "button_2", "button_3", "button_4", "shoulder_button_front_left", "shoulder_button_front_right", "shoulder_trigger_back_left", "shoulder_trigger_back_right", "select_button", "start_button", "stick_button_left", "stick_button_right", "dpad_up", "dpad_down", "dpad_left", "dpad_right"],
	Y = B.map(a => a + "_tap_target"),
	U = {
		dpad_up_left_tap_target: [12, 14],
		dpad_up_right_tap_target: [12, 15],
		dpad_down_left_tap_target: [13, 14],
		dpad_down_right_tap_target: [13, 15]
	};
class q {
	constructor(e) {
		p(this, "updateDelay");
		p(this, "axisDeadZone");
		p(this, "buttonConfigs");
		p(this, "currentStateOfGamepads");
		p(this, "gamepadConnectListeners");
		p(this, "gamepadDisconnectListeners");
		p(this, "gamepadButtonChangeListeners");
		p(this, "gamepadAxisChangeListeners");
		p(this, "_requestAnimationFrame");
		p(this, "_getGamepads");
		this.updateDelay = e.updateDelay || 0, this.axisDeadZone = e.axisDeadZone || 0, this.buttonConfigs = e.buttonConfigs || [], this.currentStateOfGamepads = [], this.gamepadConnectListeners = [], this.gamepadDisconnectListeners = [], this.gamepadButtonChangeListeners = [], this.gamepadAxisChangeListeners = [], navigator.gamepadInputEmulation = "gamepad", this._requestAnimationFrame = window.requestAnimationFrame || window.mozRequestAnimationFrame || window.webkitRequestAnimationFrame || window.msRequestAnimationFrame, this._getGamepads = navigator.getGamepads || navigator.webkitGetGamepads || navigator.mozGetGamepads || navigator.msGetGamepads, (this.gamepadApiSupported() || navigator.getNativeGamepads !== void 0) && this.tickLoop()
	}
	setButtonsConfig(e) {
		this.buttonConfigs = e
	}
	setUpdateDelay(e) {
		this.updateDelay = e
	}
	onGamepadConnect(e) {
		return this.gamepadConnectListeners.push(e), window.addEventListener("gamepadconnected", e, !0), e
	}
	offGamepadConnect(e) {
		this.gamepadConnectListeners = this.gamepadConnectListeners.filter(t => t !== e), window.removeEventListener("gamepadconnected", e, !0)
	}
	onGamepadDisconnect(e) {
		return this.gamepadDisconnectListeners.push(e), window.addEventListener("gamepaddisconnected", e, !0), e
	}
	offGamepadDisconnect(e) {
		this.gamepadDisconnectListeners = this.gamepadDisconnectListeners.filter(t => t !== e), window.removeEventListener("gamepaddisconnected", e, !0)
	}
	onGamepadAxisChange(e) {
		return this.gamepadAxisChangeListeners.push(e), e
	}
	offGamepadAxisChange(e) {
		this.gamepadAxisChangeListeners = this.gamepadAxisChangeListeners.filter(t => t !== e)
	}
	onGamepadButtonChange(e) {
		return this.gamepadButtonChangeListeners.push(e), e
	}
	offGamepadButtonChange(e) {
		this.gamepadButtonChangeListeners = this.gamepadButtonChangeListeners.filter(t => t !== e)
	}
	gamepadApiSupported() {
		const e = navigator.getNativeGamepads || navigator.getGamepads || navigator.webkitGetGamepads || navigator.mozGetGamepads || navigator.msGetGamepads;
		if (e != null && typeof e == "function") try {
			const t = e.apply(navigator);
			return t != null && (t[0] !== void 0 || t.length !== 0 || window.isSecureContext)
		} catch (t) {
			return !1
		} else return !1
	}
	getGamepads() {
		const e = navigator.getGamepads || navigator.webkitGetGamepads || navigator.mozGetGamepads || navigator.msGetGamepads;
		return e && typeof e == "function" ? e.apply(navigator) || [] : []
	}
	getCurrentGamepadStates(e = !1) {
		return e && this.checkForGamepadChanges(), this.currentStateOfGamepads
	}
	cleanup() {
		this.updateDelay = -1, this.gamepadConnectListeners.forEach(e => window.removeEventListener("gamepadconnected", e, !0)), this.gamepadDisconnectListeners.forEach(e => window.removeEventListener("gamepaddisconnected", e, !0)), this.gamepadConnectListeners = [], this.gamepadDisconnectListeners = [], this.gamepadButtonChangeListeners = [], this.gamepadAxisChangeListeners = []
	}
	tickLoop() {
		this.updateDelay < 0 || (this.checkForGamepadChanges(), this.updateDelay == 0 ? requestAnimationFrame(this.tickLoop.bind(this)) : setTimeout(() => {
			requestAnimationFrame(this.tickLoop.bind(this))
		}, this.updateDelay))
	}
	checkForGamepadChanges() {
		let e = this.getGamepads();
		for (var t = 0; t < e.length; t++) {
			let i = e[t];
			i && (this.checkForAxisChanges(t, i), this.checkForButtonChanges(t, i), this.currentStateOfGamepads[t] = i)
		}
	}
	checkForAxisChanges(e, t) {
		let i = t.axes;
		if (i.length == 0) return;
		const n = this.currentStateOfGamepads[e];
		let r = (n == null ? void 0 : n.axes) || [],
			d = [],
			o, s = !1;
		for (o = 0; o < i.length; o++) {
			let c = i[o] || 0,
				l = r[o] || 0;
			if (c != l) {
				if (Math.abs(c) < this.axisDeadZone && Math.abs(l) < this.axisDeadZone) continue;
				d[o] = !0, s = !0
			} else d[o] = !1
		}
		s && this.gamepadAxisChangeListeners.forEach(c => c(e, t, d))
	}
	checkForButtonChanges(e, t) {
		let i = t.buttons;
		if (i.length == 0) return;
		const n = this.currentStateOfGamepads[e],
			r = (n == null ? void 0 : n.buttons) || i,
			d = new Array(i.length).fill(!1);
		let o = !1;
		for (let s = 0; s < i.length; s++) {
			let c = !1;
			const l = i[s] || {
					pressed: !1,
					value: 0,
					touched: !1
				},
				u = r[s] || {
					pressed: !1,
					value: 0,
					touched: !1
				},
				m = this.buttonConfigs[s] || {},
				h = {};
			l.touched && !u.touched ? (h.touchDown = !0, c = !0) : !l.touched && u.touched && (h.touchUp = !0, c = !0), l.pressed && !u.pressed ? (h.pressed = !0, c = !0) : !l.pressed && u.pressed && (h.released = !0, c = !0), m.fireWhileHolding && l.pressed && u.pressed && (h.heldDown = !0, c = !0), l.value != u.value && (h.valueChanged = !0, c = !0), c ? (o = !0, d[s] = h) : d[s] = !1
		}
		o && this.gamepadButtonChangeListeners.forEach(s => s(e, t, d))
	}
}

function M(a, e, t) {
	const i = Math.sqrt(a * a + e * e);
	return i > t ? {
		x: a / i,
		y: e / i
	} : {
		x: a / t,
		y: e / t
	}
}

function Z(a) {
	if (a instanceof SVGGraphicsElement) {
		a.getAttribute("transform") && console.warn("VirtualGamepadLib: Setting Transform origin on an element that already has a transform attribute. This may break the transform!", a);
		const e = a.getBBox();
		a.style.transformOrigin = `${e.x+e.width/2}px ${e.y+e.height/2}px`
	} else if (a instanceof HTMLElement) {
		console.warn("VirtualGamepadLib: Setting Transform origin on an element that is not an SVG element. This may break the transform!", a);
		const e = a.getBoundingClientRect();
		a.style.transformOrigin = `${e.width/2}px ${e.height/2}px`
	}
}
const H = 18,
	X = 4,
	E = class E {
		constructor(e) {
			p(this, "getNativeGamepads");
			p(this, "buttonPressThreshold", .1);
			p(this, "realGpadToPatchedIndexMap", []);
			p(this, "patchedGpadToRealIndexMap", []);
			p(this, "emulatedGamepads", []);
			p(this, "emulatedGamepadsMetadata", []);
			p(this, "undoEventPatch", () => {});
			p(this, "AddDisplayButtonEventListeners", this.AddButtonTouchEventListeners);
			p(this, "AddDisplayJoystickEventListeners", this.AddJoystickTouchEventListeners);
			p(this, "ClearDisplayButtonEventListeners", this.ClearButtonTouchEventListeners);
			p(this, "ClearDisplayJoystickEventListeners", this.ClearJoystickTouchEventListeners);
			if (this.buttonPressThreshold = e || this.buttonPressThreshold, E.instanceRunning) throw new Error("Only one GamepadEmulator instance may exist at a time!");
			E.instanceRunning = !0, this.undoEventPatch = this.monkeyPatchGamepadEvents(), this.monkeyPatchGetGamepads()
		}
		gamepadApiNativelySupported() {
			return !!this.getNativeGamepads && !!this.getNativeGamepads.apply(navigator)
		}
		AddEmulatedGamepad(e, t, i = H, n = X) {
			if ((e === -1 || !e && e !== 0) && (e = this.nextEmptyEGpadIndex(t)), this.emulatedGamepads[e]) return !1;
			const r = {
				emulation: L.emulated,
				connected: !0,
				timestamp: performance.now(),
				displayId: "Emulated Gamepad " + e,
				id: "Emulated Gamepad " + e + " (Xinput STANDARD GAMEPAD)",
				mapping: "standard",
				index: e,
				buttons: new Array(i).fill({
					pressed: !1,
					value: 0,
					touched: !1
				}, 0, i),
				axes: new Array(n).fill(0, 0, n),
				hapticActuators: []
			};
			this.emulatedGamepads[e] = r, this.emulatedGamepadsMetadata[e] = {
				overlayMode: t
			};
			const d = new Event("gamepadconnected");
			return d.gamepad = r, window.dispatchEvent(d), r
		}
		RemoveEmulatedGamepad(e) {
			this.ClearButtonTouchEventListeners(e), this.ClearJoystickTouchEventListeners(e);
			var t = this.emulatedGamepads[e];
			if (t) {
				delete this.emulatedGamepads[e], delete this.emulatedGamepadsMetadata[e];
				const i = A(D({}, t), {
						connected: !1,
						timestamp: performance.now()
					}),
					n = new Event("gamepaddisconnected");
				n.gamepad = i, window.dispatchEvent(n)
			} else console.warn("GamepadEmulator Error: Cannot remove emulated gamepad. No emulated gamepad exists at index " + e)
		}
		PressButton(e, t, i, n) {
			var s, c, l;
			if (this.emulatedGamepads[e] == null) throw new Error("Error: PressButton() - no emulated gamepad at index " + e + ", pass a valid index, or call AddEmulatedGamepad() first to create an emulated gamepad at that index");
			const r = [...((s = this.emulatedGamepads[e]) == null ? void 0 : s.buttons) || []],
				d = i > this.buttonPressThreshold;
			if (Array.isArray(t)) {
				const u = d || (n != null ? n : (c = r[t[0]]) == null ? void 0 : c.touched) || !1;
				for (var o = 0; o < t.length; o++) {
					const m = t[o];
					if (m < 0 || m >= this.emulatedGamepads[e].buttons.length) {
						console.error("Error: PressButton() - button index " + m + " out of range, pass a valid index between 0 and " + (this.emulatedGamepads[e].buttons.length - 1));
						continue
					}
					r[m] = {
						pressed: d,
						value: i || 0,
						touched: u
					}
				}
			} else {
				const u = d || (n != null ? n : (l = r[t]) == null ? void 0 : l.touched) || !1;
				if (t < 0 || t >= this.emulatedGamepads[e].buttons.length) {
					console.error("Error: PressButton() - button index " + t + " out of range, pass a valid index between 0 and " + (this.emulatedGamepads[e].buttons.length - 1));
					return
				}
				r[t] = {
					pressed: d,
					value: i || 0,
					touched: u
				}
			}
			Object.defineProperty(this.emulatedGamepads[e], "buttons", {
				value: r,
				enumerable: !0,
				configurable: !0
			})
		}
		MoveAxis(e, t, i) {
			var r;
			if (this.emulatedGamepads[e] == null) throw new Error("Error: MoveAxis() - no emulated gamepad at index " + e + ", pass a valid index, or call AddEmulatedGamepad() first to create an emulated gamepad at that index");
			const n = [...((r = this.emulatedGamepads[e]) == null ? void 0 : r.axes) || []];
			n[t] = i, Object.defineProperty(this.emulatedGamepads[e], "axes", {
				value: n,
				enumerable: !0,
				configurable: !0
			})
		}
		AddButtonTouchEventListeners(e, t) {
			var r;
			if (!this.emulatedGamepads[e]) throw new Error("Error: AddJoystickTouchEventListeners() - no emulated gamepad at index " + e + ", pass a valid index, or call AddEmulatedGamepad() first to create an emulated gamepad at that index");
			let i = [];
			for (var n = 0; n < t.length; n++) {
				const d = t[n];
				if (!d) continue;
				const o = (r = d.buttonIndexes) != null ? r : d.buttonIndex,
					s = d.tapTarget;
				if (!s) {
					console.warn("GamepadEmulator: No tap target in gamepad " + e + " display config for button " + o + ", skipping...");
					continue
				}
				const c = h => {
					const g = h.changedTouches[0].target;
					(g == s || g.parentElement == s) && h.preventDefault()
				};
				window.addEventListener("touchstart", c, {
					passive: !1
				});
				const l = h => {
					const g = h.buttons == 1 ? 1 : 0;
					(!d.lockTargetWhilePressed || g == 0) && this.PressButton(e, o, g, !0)
				};
				s.addEventListener("pointerenter", l);
				const u = h => {
					const g = h.buttons == 1 ? 1 : 0;
					(!d.lockTargetWhilePressed || g == 0) && this.PressButton(e, o, 0, !1)
				};
				s.addEventListener("pointerleave", u);
				const m = h => {
					this.PressButton(e, o, 0, !1)
				};
				if (s.addEventListener("pointercancel", m), d.type == x.onOff) {
					const h = v => {
						v.preventDefault(), this.PressButton(e, o, 1, !0), d.lockTargetWhilePressed ? s.setPointerCapture(v.pointerId) : s.releasePointerCapture(v.pointerId)
					};
					s.addEventListener("pointerdown", h);
					const g = () => {
						this.PressButton(e, o, 0)
					};
					s.addEventListener("pointerup", g), i.push(function() {
						window.removeEventListener("touchstart", c), s.removeEventListener("pointerenter", l), s.removeEventListener("pointerleave", u), s.removeEventListener("pointerdown", h), s.removeEventListener("pointerup", g), s.removeEventListener("pointercancel", m)
					})
				} else if (d.type == x.variable) {
					const h = this.AddDragControlListener(d, (g, v, b) => {
						let f = g ? this.buttonPressThreshold + 1e-5 : 0;
						f += d.directions[w.left] || d.directions[w.right] ? Math.abs(v) : 0, f += d.directions[w.up] || d.directions[w.down] ? Math.abs(b) : 0, this.PressButton(e, o, Math.min(f, 1))
					});
					i.push(function() {
						window.removeEventListener("touchstart", c), s.removeEventListener("pointerenter", l), s.removeEventListener("pointerleave", u), s.removeEventListener("pointercancel", m), h()
					})
				}
			}
			this.emulatedGamepadsMetadata[e].removeButtonListenersFunc = () => {
				i.forEach(d => d())
			}
		}
		AddJoystickTouchEventListeners(e, t) {
			if (!this.emulatedGamepads[e]) throw new Error("Error: AddJoystickTouchEventListeners() - no emulated gamepad at index " + e + ", pass a valid index, or call AddEmulatedGamepad() first to create an emulated gamepad at that index");
			let i = [];
			for (let n = 0; n < t.length; n++) {
				const r = t[n];
				if (!r) continue;
				if (r.tapTarget == null) {
					console.warn("GamepadEmulator: No tap target in gamepad " + e + " display config for joystick " + n + ", skipping...");
					continue
				}
				const d = this.AddDragControlListener(r, (o, s, c) => {
					r.xAxisIndex !== void 0 && this.MoveAxis(e, r.xAxisIndex, s), r.yAxisIndex !== void 0 && this.MoveAxis(e, r.yAxisIndex, c)
				});
				i.push(d)
			}
			this.emulatedGamepadsMetadata[e].removeJoystickListenersFunc = () => {
				i.forEach(n => n())
			}
		}
		ClearButtonTouchEventListeners(e) {
			var t;
			this.emulatedGamepadsMetadata[e] && ((t = this.emulatedGamepadsMetadata[e]) != null && t.removeButtonListenersFunc) && this.emulatedGamepadsMetadata[e].removeButtonListenersFunc()
		}
		ClearJoystickTouchEventListeners(e) {
			var t;
			this.emulatedGamepadsMetadata[e] && ((t = this.emulatedGamepadsMetadata[e]) != null && t.removeJoystickListenersFunc) && this.emulatedGamepadsMetadata[e].removeJoystickListenersFunc()
		}
		AddDragControlListener(e, t) {
			let i = {
					startX: 0,
					startY: 0
				},
				n = -1;
			const r = s => {
					var c = s.pointerId;
					if (n === c) {
						const l = e.directions[w.left] ? -1 : 0,
							u = e.directions[w.right] ? 1 : 0,
							m = e.directions[w.up] ? -1 : 0,
							h = e.directions[w.down] ? 1 : 0,
							g = s.clientX - i.startX,
							v = s.clientY - i.startY;
						let {
							x: b,
							y: f
						} = M(g, v, e.dragDistance);
						b = Math.max(Math.min(b, u), l), f = Math.max(Math.min(f, h), m), t(!0, b, f)
					}
				},
				d = s => {
					n == s.pointerId && (document.removeEventListener("pointermove", r, !1), document.removeEventListener("pointerup", d, !1), n = -1, t(!1, 0, 0))
				};
			e.tapTarget.addEventListener("pointerdown", s => {
				s.preventDefault(), i.startX = s.clientX, i.startY = s.clientY, n = s.pointerId, e.lockTargetWhilePressed ? e.tapTarget.setPointerCapture(s.pointerId) : e.tapTarget.releasePointerCapture(s.pointerId), t(!0, 0, 0), document.addEventListener("pointermove", r, !1), document.addEventListener("pointerup", d, !1)
			});
			const o = s => {
				s.changedTouches[0].target == e.tapTarget && s.preventDefault()
			};
			return window.addEventListener("touchstart", o, {
					passive: !1
				}),
				function() {
					window.removeEventListener("touchstart", o), e.tapTarget.removeEventListener("pointerdown", r)
				}
		}
		cloneGamepad(e) {
			if (!e) return e;
			const t = e.axes ? e.axes.length : 0,
				i = e.buttons ? e.buttons.length : 0,
				n = {};
			for (let r in e)
				if (r === "axes") {
					const d = new Array(t);
					for (let o = 0; o < t; o++) d[o] = Number(e.axes[o]);
					Object.defineProperty(n, "axes", {
						value: d,
						enumerable: !0,
						configurable: !0
					})
				} else if (r === "buttons") {
				const d = new Array(i);
				for (let o = 0; o < i; o++) {
					const s = e.buttons[o];
					if (s == null) d[o] = s;
					else {
						const c = s.pressed,
							l = s.value,
							u = s.touched || !1;
						d[o] = {
							pressed: c,
							value: l,
							touched: u
						}
					}
				}
				Object.defineProperty(n, "buttons", {
					value: d,
					enumerable: !0,
					configurable: !0
				})
			} else Object.defineProperty(n, r, {
				get: () => e[r],
				configurable: !0,
				enumerable: !0
			});
			return n.emulation || Object.defineProperty(n, "emulation", {
				value: L.real,
				configurable: !0,
				enumerable: !0
			}), n
		}
		nextEmptyEGpadIndex(e) {
			let t = 0;
			if (e)
				do {
					if (!this.emulatedGamepads[t]) break;
					t++
				} while (t < this.emulatedGamepads.length);
			else {
				const i = Math.max(this.emulatedGamepads.length, this.patchedGpadToRealIndexMap.length);
				do {
					if (!this.emulatedGamepads[t] && this.patchedGpadToRealIndexMap[t] == null) break;
					t++
				} while (t < i)
			}
			return t
		}
		nextEmptyRealGpadIndex(e) {
			let t = e;
			const i = Math.max(this.emulatedGamepads.length, this.patchedGpadToRealIndexMap.length);
			do {
				const n = this.emulatedGamepadsMetadata[t],
					r = this.realGpadToPatchedIndexMap[t] == null && this.patchedGpadToRealIndexMap[t] == null;
				if (n && n.overlayMode || !n && r) break;
				t++
			} while (t < i);
			return t
		}
		monkeyPatchGamepadEvents() {
			let e, t, i, n;
			window.hasOwnProperty("ongamepadconnected") && (e = Object.getOwnPropertyDescriptor(window, "ongamepadconnected"), e.configurable = !0, i = window.ongamepadconnected, window.ongamepadconnected = null, Object.defineProperty(window, "ongamepadconnected", {
				get: () => function(o) {},
				set: o => {
					i = o
				},
				configurable: !0
			})), window.hasOwnProperty("ongamepaddisconnected") && (t = Object.getOwnPropertyDescriptor(window, "ongamepaddisconnected"), t.configurable = !0, n = window.ongamepaddisconnected, window.ongamepaddisconnected = null, Object.defineProperty(window, "ongamepaddisconnected", {
				get: () => function(o) {},
				set: o => {
					i = o
				},
				configurable: !0
			}));
			const r = o => {
				const s = o.gamepad;
				if (s && s.emulation === void 0) {
					o.stopImmediatePropagation(), o.preventDefault();
					const c = this.cloneGamepad(o.gamepad),
						l = c.index,
						u = this.nextEmptyRealGpadIndex(l);
					this.realGpadToPatchedIndexMap[l] = u, this.patchedGpadToRealIndexMap[u] = l, Object.defineProperty(c, "index", {
						get: () => u
					}), Object.defineProperty(c, "emulation", {
						get: () => L.real
					});
					const m = new Event(o.type || "gamepadconnected");
					m.gamepad = c, window.dispatchEvent(m)
				}
				i && i.call(window, o)
			};
			window.addEventListener("gamepadconnected", r);
			const d = o => {
				const s = o.gamepad;
				if (s && s.emulation === void 0) {
					o.stopImmediatePropagation(), o.preventDefault();
					const c = this.cloneGamepad(o.gamepad),
						l = this.realGpadToPatchedIndexMap[c.index] || c.index;
					Object.defineProperty(c, "index", {
						get: () => l
					}), Object.defineProperty(c, "emulation", {
						get: () => L.real
					}), delete this.realGpadToPatchedIndexMap[c.index], delete this.patchedGpadToRealIndexMap[l];
					const u = new Event(o.type || "gamepaddisconnected");
					u.gamepad = c, window.dispatchEvent(u)
				}
				n && n.call(window, o)
			};
			return window.addEventListener("gamepaddisconnected", d),
				function() {
					window.removeEventListener("gamepadconnected", r), window.hasOwnProperty("ongamepadconnected") && (Object.defineProperty(window, "ongamepadconnected", e), window.ongamepadconnected = i), window.removeEventListener("gamepaddisconnected", d), window.hasOwnProperty("ongamepaddisconnected") && (Object.defineProperty(window, "ongamepaddisconnected", t), window.ongamepaddisconnected = n)
				}
		}
		monkeyPatchGetGamepads() {
			const e = this;
			let t = navigator.getGamepads || navigator.webkitGetGamepads || navigator.mozGetGamepads || navigator.msGetGamepads;
			this.getNativeGamepads = t, navigator.getNativeGamepads = t || function() {
				return []
			}, Object.defineProperty(navigator, "getGamepads", {
				configurable: !0,
				value: function() {
					var d, o, s, c;
					let i = e.emulatedGamepads,
						n = t != null ? t.apply(navigator) || [] : [],
						r = new Array(Math.max(n.length, i.length)).fill(null);
					for (let l = 0; l < n.length; l++) {
						const u = n[l];
						if (!u) continue;
						let m = e.cloneGamepad(u),
							h = e.realGpadToPatchedIndexMap[m.index] || m.index;
						Object.defineProperty(m, "index", {
							get: () => h
						}), r[h] = m
					}
					for (let l = 0; l < i.length; l++) {
						let u = r[l],
							m = i[l];
						if (m && u) {
							Object.defineProperty(r[l], "emulation", {
								value: L.overlay,
								configurable: !0
							});
							let h = Math.max((o = (d = u == null ? void 0 : u.buttons) == null ? void 0 : d.length) != null ? o : 0, m.buttons.length),
								g = new Array(h);
							for (let f = 0; f < h; f++) {
								const y = (m == null ? void 0 : m.buttons[f]) || {
										touched: !1,
										pressed: !1,
										value: 0
									},
									G = (u == null ? void 0 : u.buttons[f]) || {
										touched: !1,
										pressed: !1,
										value: 0
									};
								g[f] = {
									touched: y.touched || G.touched || !1,
									pressed: y.pressed || G.pressed || !1,
									value: Math.max(y.value, G.value) || 0
								}
							}
							Object.defineProperty(r[l], "buttons", {
								value: g,
								enumerable: !0,
								configurable: !0
							});
							let v = Math.max(m.axes.length, u.axes.length),
								b = new Array(h);
							for (let f = 0; f < v; f++) {
								const y = (s = m.axes[f]) != null ? s : 0,
									G = (c = u.axes[f]) != null ? c : 0;
								b[f] = Math.abs(y) > Math.abs(G) ? y : G
							}
							Object.defineProperty(r[l], "axes", {
								value: b,
								enumerable: !0,
								configurable: !0
							})
						} else m && (Object.defineProperty(m, "emulation", {
							value: L.emulated,
							enumerable: !0,
							configurable: !0
						}), Object.defineProperty(m, "timestamp", {
							value: performance.now(),
							enumerable: !0,
							configurable: !0
						}), r[l] = e.cloneGamepad(m))
					}
					return r
				}
			})
		}
		cleanup() {
			for (let e = 0; e < this.emulatedGamepads.length; e++) this.ClearButtonTouchEventListeners(e), this.ClearJoystickTouchEventListeners(e);
			this.emulatedGamepads = [], this.undoEventPatch(), this.getNativeGamepads ? Object.defineProperty(navigator, "getGamepads", {
				value: this.getNativeGamepads,
				configurable: !0
			}) : Object.defineProperty(navigator, "getGamepads", {
				value: void 0,
				configurable: !0
			}), E.instanceRunning = !1, delete navigator.getNativeGamepads
		}
	};
p(E, "instanceRunning", !1);
var GamepadEmulator = E;
// export {
// 	Z as C, H as D, C as G, B as P, q as a, X as b, F as c, Y as d, w as e, U as f, x as g, S as h, L as i, j as s
// };
